const AccessApi = {
    link: 'https://api.themoviedb.org/3',
    key: '4113f3ad734e747a5b463cde8c55de42',
}

export default AccessApi;